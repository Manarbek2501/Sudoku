//
//  Timer.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 29.04.2023.
//

import Foundation
import SwiftUI

struct SudokuTime: Codable {
    let time: Int
}

extension UserDefaults {
    private static let bestTimesKey = "bestTimes"
    var bestTimes: [SudokuTime] {
        get {
            guard let data = data(forKey: Self.bestTimesKey) else {
                return []
            }
            
            let decoder = JSONDecoder()
            return (try? decoder.decode([SudokuTime].self, from: data)) ?? []
        }
        
        set {
            let encoder = JSONEncoder()
            guard let data = try? encoder.encode(newValue) else {
                return
            }
            
            setValue(data, forKey: Self.bestTimesKey)
        }
    }
}

class TimerManager: ObservableObject {
    @Published var elapsedTime: TimeInterval = 0
    private var timer: Timer?

    func start() {
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { [weak self] _ in
            self?.elapsedTime += 1
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }

    func reset() {
        elapsedTime = 0
        stop()
    }
}

