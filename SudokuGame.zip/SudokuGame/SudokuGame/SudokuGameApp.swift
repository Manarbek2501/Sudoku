//
//  SudokuGameApp.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 29.04.2023.
//

import SwiftUI

@main
struct SudokuGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
