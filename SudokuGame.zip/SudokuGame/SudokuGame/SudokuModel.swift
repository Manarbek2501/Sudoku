//
//  SudokuModel.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 30.04.2023.
//
import Foundation
import SwiftUI

class SudokuModel: ObservableObject {
    @Published var squareVal: Int
    @Published var index: Int
    @Published var row: Int
    @Published var col: Int
    @Published var isPermanent: Bool
    @Published var isHint: Bool
    @Published var isWrong: Bool
    
    init(value: Int, index: Int, rowCol:[Int], isPermanent:Bool) {
        self.squareVal = value
        self.index = index
        self.row = rowCol[0]
        self.col = rowCol[1]
        self.isPermanent = isPermanent
        self.isHint = false
        self.isWrong = false
    }
}

struct SudokuModalView: View {
        @ObservedObject var data: SudokuModel
        
        var onclick: () -> Void
        
        var squareColor: Color {
            
            if (((self.data.col > 5 || self.data.col < 3) && (self.data.row > 5 || self.data.row < 3)) ||
                ((self.data.col <= 5 && self.data.col >= 3) && (self.data.row <= 5 && self.data.row >= 3))) {
                return .blue.opacity(1)
            } else {
                return .blue.opacity(0.5)
            }
        }
        
        var squareWeight: Font.Weight {
            if (self.data.isHint) {
                return .bold
            }
            if (self.data.isWrong) {
                return .bold
            }
            
            return self.data.isPermanent ? .bold : .light
        }
        
        var squareTextColor: Color {
            if (self.data.isHint) {
                return .white
            } else if (self.data.isWrong) {
                return .red.opacity(0.5)
            } else {
                return .white
            }
        }
        
        var body: some View {
            Button(action: {
                self.onclick()
            }, label: {
                Text(self.data.squareVal != 0 ? String(self.data.squareVal) : " ")
                    .foregroundColor(squareTextColor)
                    .fontWeight(squareWeight)
                    .frame(width:40, height:40, alignment: .center)
                    .border(Color.white)
                    .background(squareColor)
            })
        }
}
