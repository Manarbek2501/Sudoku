//
//  ContentView.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 29.04.2023.
//

import SwiftUI

enum Complexity: String, CaseIterable, Identifiable {
    case easy
    case medium
    case hard
    
    var id: Complexity {self}
    
    var complexityName: String {
        switch self {
        case .easy:
           return "Easy"
        case .medium:
           return "Medium"
        case .hard:
           return "Hard"
        }
    }
}

struct ContentView: View {
    @StateObject var modal = SudokuSolver()
    @State var complexitySelected = Complexity.easy
    @State var bestTimes: [SudokuTime] = UserDefaults.standard.bestTimes
    @State var timeElapsed = 0
    @StateObject var timer = TimerManager()
    @State var isStartEasy: Bool = false
    @State var isStartMedium: Bool = false
    @State var isStartHard: Bool = false
    
    var difficultyArray = ["Easy", "Medium", "Hard"]
    var body: some View {
        VStack {
            Text("SuDoKu")
                .foregroundColor(.blue)
                .font(.system(size: 42))
                .fontWeight(.black)
            ZStack {
                RoundedRectangle(cornerRadius: 16)
                    .fill(.linearGradient(colors: [.blue, .white], startPoint: .leading, endPoint: .trailing))
                HStack {
                    Text("Choose the difficulty")
                        .foregroundColor(.white)
                        .font(.system(size: 18))
                        .fontWeight(.semibold)
                    Spacer()
                    Picker("Please choose a color", selection: $complexitySelected) {
                        ForEach(Complexity.allCases) { complexity in
                            Text(complexity.rawValue.capitalized)
                        }
                    }
                    .pickerStyle(.menu)
                }
                .padding()
            }
            .frame(height: 70)
            
            if complexitySelected == .easy {
                Button("Start") {
                    isStartEasy.toggle()
                    timer.start()
                }
                .frame(width:150 ,height: 56)
                .background(Color.blue)
                .cornerRadius(16)
                .foregroundColor(.white)
                .padding()
                if isStartEasy{
                    SudokuView()
                }
                    
            } else if complexitySelected == .medium {
                Button("Start") {
                    isStartMedium.toggle()
                }
                .frame(width:150 ,height: 56)
                .background(Color.blue)
                .cornerRadius(16)
                .foregroundColor(.white)
                .padding()
                if isStartMedium{
                    SudokuMediumView()
                }
            } else if complexitySelected == .hard {
                Button("Start") {
                    isStartHard.toggle()
                }
                .frame(width:150 ,height: 56)
                .background(Color.blue)
                .cornerRadius(16)
                .foregroundColor(.white)
                .padding()
                if isStartHard{
                    SudokuHardView()
                }
            }
            
            Spacer()
            HStack{
                Text("Time: \(timer.elapsedTime)")
                    .foregroundColor(.gray)
                if isStartEasy {
                    Button("Stop") {
                        timer.stop()
                    }
                    Button("Reset") {
                        timer.reset()
                        isStartEasy = false
                    }
                }
                if isStartHard {
                    Button("Stop") {
                        timer.stop()
                    }
                    Button("Reset") {
                        timer.reset()
                        isStartHard = false
                    }
                }
                if isStartMedium {
                    Button("Stop") {
                        timer.stop()
                    }
                    Button("Reset") {
                        timer.reset()
                        isStartMedium = false
                    }
                }
//                Spacer()
                
            }
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
