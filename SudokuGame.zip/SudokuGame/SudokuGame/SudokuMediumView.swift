//
//  SudokuMediumComplex.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 29.04.2023.
//

import SwiftUI

struct SudokuMediumView: View {
    var body: some View {
        SudokuGrid()
    }
}

struct SudokuMediumView_Previews: PreviewProvider {
    static var previews: some View {
        SudokuMediumView()
    }
}
