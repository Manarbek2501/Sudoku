//
//  SudokuGrid.swift
//  SudokuGame
//
//  Created by Manarbek Bibit on 30.04.2023.
//

import SwiftUI

struct SudokuGrid: View {
    @StateObject var modal = SudokuSolver()
    @State var isSolved: Bool = false
    @State var selectedVal: Int = 0
    @State var undoStack: [(from: Int, index: Int, value: Int)] = []
    @State var redoStack: [(from: Int, index:Int, value:Int)] = []
    
    func getButtonColor(currentVal: Int, selectedVal: Int) -> Color {
        if (currentVal == selectedVal) {
            return Color.blue.opacity(1)
        } else {
            return Color.white.opacity(0.5)
        }
    }
    
    func setSelectedVal(selected: Int) -> Void {
        selectedVal = selected
    }
    
    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Spacer()
                Button("New Game") {
                    self.modal.makeNewBoard()

                }
            }
            .padding([.leading, .trailing], 16)
            VStack(spacing: 0) {
                ForEach(0 ..< modal.items.count / 9, content: { row in
                    HStack(spacing:0) {
                        ForEach(0 ..< 9, content: { col in
                            let index = row * 9 + col
                            SudokuModalView(data: modal.items[index], onclick: {
                                if (self.modal.items[index].squareVal == selectedVal) {return}
                                self.undoStack.append((self.modal.items[index].squareVal, index, selectedVal))
                                self.modal.setSquare(index: index, newVal: selectedVal)
                            })
                        })
                    }
                })
            }
            VStack(spacing:2) {
                HStack(spacing:2) {
                    ForEach(-2 ..< 4, content: { val in
                        Button(action: {
                            if (val >= 0) {
                                self.setSelectedVal(selected: val)
                                self.redoStack.removeAll()
                            } else if (val == -2) {
                                // undo action. So take it off top of undo stack, add it to redo stack
                                if (undoStack.count == 0) {return}
                                let lastAction = self.undoStack.removeLast()
                                self.redoStack.append(lastAction)
                                self.modal.setSquare(index: lastAction.1, newVal: lastAction.0)
                            } else if (val == -1) {
                                // redo action. So take it off of redo stack and add it to undo stack
                                if (redoStack.count == 0) {return}
                                let lastAction = self.redoStack.removeLast()
                                self.undoStack.append(lastAction)
                                self.modal.setSquare(index: lastAction.1, newVal: lastAction.2)
                            }
                        }, label: {
                            if (val == 0) {
                                Image("eraser")
                                    .foregroundColor(Color.black)
                                    .frame(width:30, height:30, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else if (val == -1) {
                                Image(systemName:"arrow.uturn.forward")
                                    .foregroundColor(Color.black)
                                    .frame(width:30, height:30, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else if (val == -2) {
                                Image(systemName:"arrow.uturn.backward")
                                    .foregroundColor(Color.black)
                                    .frame(width:30, height:30, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            } else {
                                Text(String(val))
                                    .bold()
                                    .foregroundColor(Color.black)
                                    .frame(width:30, height:30, alignment: .center)
                                    .border(Color.gray)
                                    .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                            }
                        })
                    })
//                }
//                HStack(spacing:2) {
                    ForEach(4 ..< 10, content: { val in
                        Button(action: {
                            self.setSelectedVal(selected: val)
                        }, label: {
                            Text(String(val))
                                .foregroundColor(Color.black)
                                .bold()
                                .frame(width:30, height:30, alignment: .center)
                                .border(Color.gray)
                                .background(getButtonColor(currentVal: val, selectedVal: selectedVal))
                        })
                    })
                }

            }
            HStack {
            Button(action: {
                self.modal.revealOne()
            }, label: {
                Text("Reveal One")
            })
                Button(action: {
                    self.modal.solveBoard()
                }, label: {
                    Text("View Solution")
                })
            }
        }
    }
}

struct SudokuGrid_Previews: PreviewProvider {
    static var previews: some View {
        SudokuGrid()
    }
}
